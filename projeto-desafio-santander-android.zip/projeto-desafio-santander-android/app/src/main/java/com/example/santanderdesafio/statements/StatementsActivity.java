package com.example.santanderdesafio.statements;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.santanderdesafio.R;

public class StatementsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_releases);


    }
}
